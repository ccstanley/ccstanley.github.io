# KaiOS Ad integration

This repo contains a sample certified app that can load a remote ad script without granting it elevated privileges and without needing a remote wrapper frame.

The setup is as follows:
- The app loads an `ad-wrapper.html` iframe from a local http server running on the device. We already need one for the new api we expose for WA, so that doesn't imply more work. Because this iframe is cross origin, it doesn't get the app permissions.
- The ad wrapper initializes itself, and notifies the app when it's ready. The app then sends back the user information, and the url of the ad script to load.
- The ad wrapper loads the ad content, which only has access to the ad frame, like if this was a normal web page.

By managing the focus properly, the user can reach content in the ad frame and activate it.

# Testing

- get root & remount: `adb root && adb remount`.
- push the `install-prefs.js` to your device: `adb push install-prefs.js /system/b2g/defaults/pref/`.
- restart b2g: `adb shell stop b2g && adb shell start b2g`.
- push the app to the device.

Then we need to simulate the on-device http server and the remote Ad server. For that we use TCP redirection from the device to your host. Since origins are based on host name + port, we still get cross origin checks.

For the device server:
- `adb reverse tcp:8081 tcp:8080`
- `cd device`
- `python -m SimpleHTTPServer 8080`

For the ad server:
- `adb reverse tcp:9090 tcp:8090`
- `cd remote`
- `python -m SimpleHTTPServer 8090`

That's it! You can then launch the app, check that what is displayed makes sense, an click on the link in the ad frame.

# The Ad SDK for KaiOS

The current POC implements a basic Ads SDK which is served from the device alongside the ad wrapper.
To use this SDK, an app needs to:
- Load the ads sdk script from `http://127.0.0.1:8081/sdk/ads/ads-sdk.js`.
- Create an `<iframe>` in which `http://127.0.0.1:8081/sdk/ads/ad-wrapper.html` will be loaded.
- Configure and initialize the Ads Sdk.

## Configuring the SDK

The `KaiAdsSdk` object can be setup with 2 callbacks: `onready` and `onexit`.

### The onready callback

This callback takes no parameter, and needs to return a `{ content, target }` object. It is called when the ad wrapper is ready.
The `content` property is the full content that will be injected in the ad frame, as a string.
The `target` property is the ID of the frame element in which to inject the content.

### The onexit callback

This callback is called when the focus can be transfered back to the main application from the ad frame.


## Initializing the SDK

Simply call `KaiAdsSdk.init()` to setup the SDK once it is configured.
