const KaiAdsSdkDemo = (frameID) => {
  const adFrameOrigin = "http://local-device.kaiostech.com:8081";
  const adFrameSrc =
    adFrameOrigin +
    "/sdk/ads/ad-wrapper.html#o=" +
    encodeURIComponent(window.location.origin) +
    "&w=" +
    encodeURIComponent(window.innerWidth) +
    "&h=" +
    encodeURIComponent(window.innerHeight);

  let handlers = {};

  const getActiveAdFrame = () => {
    const frame = document.getElementById(frameID);
    return frame ? frame : null;
  };

  const KaiAdsSdkSetup = () => {
    KaiAdsSdk.onready = () => {
      console.log("KaiAdsSdk.onready");
      // Google Ads.
      let content = `
      <style>
        body {
          margin: 0;
          background-color: white;
        }
        .navbar {
          position: absolute;
          bottom: 0px;
          width: 100%;
          background-color: grey;
          height: 30px;
        }
        .dismissBtn {
          float: right;
          text-align: right;
          padding-right: 3%;
          font-weight: 600;
          font-size: 14px;
          line-height: 30px;
        }
      </style>
      <script>
        // new URLSearchParams isn't supported on firefoxox based 48 (?)
        function getParameterByName(name) {
          const params = window.location.hash.substring(1).split("&");
          for (let i = 0; i < params.length; i++) {
            if (params[i].substring(0, name.length + 1) === name + "=") {
              return decodeURIComponent(params[i].substring(2));
            }
          }
          return null;
        }

        window.kaiOpts = {
          appOrigin: getParameterByName("o"),
          reqWidth: getParameterByName("w"),
          reqHeight: getParameterByName("h"),
        };

        const onKeyDown = (key) => {
          if (key === "Backspace" || key === "EndCall" || key === "SoftRight") {
            window.parent.postMessage(
              JSON.stringify({
                event: "close",
                args: [],
              }),
              window.kaiOpts.appOrigin
            );
          }
        };
        window.addEventListener("keydown", (e) => {
          onKeyDown(e.key);
        });
        window.addEventListener("message", (e) => {
          console.log(e);
          if (e.origin !== window.kaiOpts.appOrigin) {
            return;
          }
          const payload = JSON.parse(e.data);
          if (payload.event === "keydown") {
            onKeyDown(payload.args[0]);
          }
        });
      </script>
      <script
        async="async"
        src="https://securepubads.g.doubleclick.net/tag/js/gpt.js"
      ></script>
      <script>
        window.googletag = window.googletag || { cmd: [] };
      </script>
      <script>
        googletag.cmd.push(function () {
          googletag
            .defineSlot(
              "/37179215/MOBILE_TRAIN_LIST_BOTTOM_300X250",
              [300, 250],
              "div-gpt-ad-1589095880942-0"
            )
            .addService(googletag.pubads());
          googletag.pubads().enableSingleRequest();
          googletag.enableServices();
          googletag.pubads().set("page_url", "indiatoday.in");
        });
      </script>
      <div id="div-gpt-ad-1589095880942-0">
        <script>
          googletag.cmd.push(function () {
            googletag.display("div-gpt-ad-1589095880942-0");

            // Scale to fit onto screen
            const scale = Math.min(
              parseInt(window.kaiOpts.reqWidth) / 300,
              parseInt(window.kaiOpts.reqHeight) / 250
            );

            const tag = document.getElementById("div-gpt-ad-1589095880942-0");
            tag.style.transform = "scale(" + scale + ")";
            tag.style.transformOrigin = "0";
          });
        </script>
      </div>
      <nav class="navbar">
        <span class="dismissBtn">Dismiss</span>
      </nav>
      <script>
        var dismissBtn = document.getElementsByClassName("dismissBtn")[0];
        var navbar = document.getElementsByClassName("navbar")[0];

        dismissBtn.addEventListener("click", function () {
          var msg = {
            event: "close",
            args: [],
          };
          window.parent.postMessage(
            JSON.stringify(msg),
            window.kaiOpts.appOrigin
          );
        });
      </script>
    `;

      navigator.spatialNavigationEnabled = true;
      console.log("set spatialNavigationEnabled true");

      target_frame = frameID;
      return { content, target_frame };
    };

    // KaiAdsSdk.onexit = () => {
    //   // Transfert the focus back to the main frame.
    //   resetFocus(currentIndex - 1);
    // };

    KaiAdsSdk.init();
  };

  /**
   *
   * @param {KeyboardEvent} e
   * @returns
   */
  const onKeydown = (e) => {
    const frame = getActiveAdFrame();
    if (!frame) {
      return;
    }
    // Prevent main frame from handling these keys - just let ad frame handle it
    const ignoreKeys = ["EndCall", "SoftRight", "Backspace"];
    if (ignoreKeys.indexOf(e.key) <= -1) {
      e.preventDefault();
      e.stopPropagation();
    }
    console.log(e);

    frame.contentWindow.postMessage(
      JSON.stringify({
        event: "keydown",
        args: [e.key],
      }),
      adFrameOrigin
    );
  };

  /**
   * postMessage Event Listener
   * @param {MessageEvent} e
   * @returns
   */
  const onMessage = (e) => {
    console.log(e);

    // Validation of messages
    if (e.origin !== adFrameOrigin) {
      return;
    }
    let payload;
    try {
      payload = JSON.parse(e.data);
    } catch (e) {
      return;
    }

    if (!payload.event || !payload.args) {
      return;
    }

    if (payload.event === "close") {
      const frame = getActiveAdFrame();
      if (frame) {
        frame.remove();
      }
    }
    if (handlers["ad" + payload.event]) {
      handlers["ad" + payload.event](payload.args);
    }
  };

  /**
   * Init ad frame
   * @param {HTMLIFrameElement} frame
   */
  const initFrame = (frame) => {
    frame.onload = () => {
      frame.style.display = "block";
    };
    frame.style.display = "none";
    frame.src = adFrameSrc;

    window.addEventListener("message", onMessage);
    window.addEventListener("keydown", onKeydown);
  };

  // Init and go
  return {
    init: (options) => {
      Object.assign(handlers, options.listeners || {});
      KaiAdsSdkSetup();
      initFrame(document.getElementById(frameID));
    },
    destroy: () => {
      handlers = {};
      window.removeEventListener("message", onMessage);
      window.removeEventListener("keydown", onKeydown);
    },
  };
};
