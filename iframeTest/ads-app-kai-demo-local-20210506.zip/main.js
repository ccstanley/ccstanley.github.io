document.addEventListener("DOMContentLoaded", () => {
  // // Check that we have access to the contacts api.
  // let node = document.getElementById("count");
  // if (navigator.mozContacts) {
  //   let req = navigator.mozContacts.getCount();
  //   req.onsuccess = () => {
  //     node.textContent = `${req.result} contacts`;
  //   }
  // } else {
  //   node.textContent = "No access to contacts";
  // }

  // Set the focus and start listening to key events.
  resetFocus(0);
  document.body.addEventListener("keydown", handleKeydownEvent);
});

// Very basic navigation/focus handler...
var currentIndex = 0;

function resetFocus(index) {
  const items = document.querySelectorAll(".items");
  if (items.length > 0) {
    currentIndex = index;
    items[currentIndex].focus();
  }
}

function nav(move) {
  let old = currentIndex;
  var items = document.querySelectorAll(".items");
  var next = currentIndex + move;
  if (next < 0) {
    next = items.length - 1;
  }
  if (next == items.length) {
    next = 0;
  }
  var targetElement = items[next];
  if (targetElement) {
    targetElement.focus();
  }
  currentIndex = next;
}

function handleKeydownEvent(e) {
  switch (e.key) {
    case "ArrowUp":
    case "ArrowLeft":
      nav(-1);
      break;
    case "ArrowDown":
    case "ArrowRight":
      nav(1);
      break;
  }
}

// End of the navigation/focus handler.
const sdk = KaiAdsSdkDemo("ad-frame");
sdk.init({
  listeners: {
    adclose: () => {
      console.log("ad close");
    },
  },
});
navigator.spatialNavigationEnabled = true;
console.log("set spatialNavigationEnabled true");
